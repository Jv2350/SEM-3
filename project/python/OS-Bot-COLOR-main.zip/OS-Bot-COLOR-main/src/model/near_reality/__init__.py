from .combat import NRCombat
from .fishing import NRFishing
from .mining import NRMining
from .pickpocket import NRPickpocket
from .woodcutting import OSNRWoodcutting
