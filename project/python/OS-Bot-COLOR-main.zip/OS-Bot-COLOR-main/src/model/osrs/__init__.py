from .combat.combat import OSRSCombat
from .woodcutter import OSRSWoodcutter
