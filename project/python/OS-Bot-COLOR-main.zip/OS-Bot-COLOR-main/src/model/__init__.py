from .bot import *
from .near_reality import *
from .osrs import *
from .runelite_bot import *
from .zaros import *
