The properties files in this folder must have names that directly correspond to the game they are meant for.
The format is `{game_title}_settings.properties`.

All Bots have a `game_title` property. That property is used to locate this settings file.
